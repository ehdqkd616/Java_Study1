
public class MyDateExample {

	public static void main(String[] args) {
		MyDate date = new MyDate();
//		date.year = 2020;
//		date.month = 100;
		date.setYear(2020);
		date.setMonth(3000);
		date.setDay(50202);
		System.out.println(date);
	}

}
