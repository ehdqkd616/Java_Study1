
public class AnimalExample {

	public static void main(String[] args) {
		Animal d1 = new Animal("Rudy", 2, "GoldenRetriever",50);
		d1.play();
		d1.walk();
		d1.eat("사료");
	
	}

}
