//클래스 이름은 파일과 같아야 한다.
public class HelloWorld {

	//적힌 내용을 실행하는 메서드(=함수)
	public static void main(String[] args) {
		//콘솔(터미널)에 출력하는 메서드
		System.out.println("Hello World!");
		
	}

}
