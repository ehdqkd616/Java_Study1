
public class BooleanExample {

	public static void main(String[] args) {
		boolean a = true;
//		a = 1; boolean은 1bit 짜리 true, false 키워드만 사용 가능

	}

}
