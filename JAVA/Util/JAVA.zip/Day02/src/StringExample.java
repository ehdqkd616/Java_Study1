
public class StringExample {

	public static void main(String[] args) {
		String a = "\"안녕하세요.\"";//string이 대문자인 이유?
		String b = null;
		b = "";
		String c = "귀하의 잔액은 : ";
		int money = 1000;
		System.out.println(a+c+(money+1000));
		
	}

}
