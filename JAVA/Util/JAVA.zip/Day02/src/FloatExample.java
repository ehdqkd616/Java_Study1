
public class FloatExample {

	public static void main(String[] args) {
		float f = 1.1f;//float 사용시에는 f 작성
		double d = 1.1;
	}

}
