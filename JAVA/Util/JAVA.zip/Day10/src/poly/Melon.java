package poly;

public class Melon extends Fruit {

	public String getName() {
		return name;
	}
	
	public Melon() {
		this.name = "멜론";
	}
	
}
