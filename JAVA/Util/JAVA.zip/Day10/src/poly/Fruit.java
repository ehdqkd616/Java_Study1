package poly;

public class Fruit {
	
	public String name;
	
	public String getName() {
		return this.name;
	}
	
}