package poly;

public class Apple extends Fruit {
	
	public String getName() {
		return name;
	}
	
	public Apple() {
		this.name = "사과";
	}
	
}
