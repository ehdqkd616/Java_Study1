package poly;

public class Grape extends Fruit {
	
	public String getName() {
		return name;
	}
	
	public Grape() {
		this.name = "포도";
	}
	
}
