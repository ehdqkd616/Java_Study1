package poly;

public class Banana extends Fruit {
	
	public String getName() {
		return name;
	}
	
	public Banana() {
		this.name = "바나나";
	}
	
}
