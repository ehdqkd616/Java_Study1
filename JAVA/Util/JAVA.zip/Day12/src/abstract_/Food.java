package abstract_;

public interface Food {

	String getName();
	
}
