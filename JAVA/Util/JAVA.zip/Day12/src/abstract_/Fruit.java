package abstract_;

public abstract class Fruit {
	
	public String name;
	
	public String getName() {
		return this.name;
	}
	
}