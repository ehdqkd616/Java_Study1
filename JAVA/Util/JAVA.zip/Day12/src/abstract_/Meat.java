package abstract_;

public abstract class Meat {

	public String name;
	
	public abstract String getName();
	
	
} 