package abstract_;

public abstract class Shape {

	protected int x;
	protected int y;
	
	protected abstract double getArea();
	
}
