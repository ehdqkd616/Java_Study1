package interface_;

public interface A3 extends A1,A2 {

	void a3();
	
}
