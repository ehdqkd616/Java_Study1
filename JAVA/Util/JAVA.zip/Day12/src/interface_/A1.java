package interface_;

public interface A1 {
	
	void a1();
	
}
