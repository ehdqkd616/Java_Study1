package interface_;

public interface A2 {

	void a2();
	
}
