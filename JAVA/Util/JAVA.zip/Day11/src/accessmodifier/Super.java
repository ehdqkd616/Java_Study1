package accessmodifier;

public class Super {

	public int a = 10;
	protected int b = 10;
	/*package friendly*/ int c = 10;
	private int d = 10;
	
}
