package accessmodifier;

public class Sub extends Super{
	
	public void print() {
		System.out.println(a);
		System.out.println(b);
//		System.out.println(c);
	}
	
}
