package accessmodifier;

public class AccessExample {

	public static void main(String[] args) {
		Super s = new Super();
		System.out.println(s.d);
		Sub sub = new Sub();
		
	}
	
	
}
