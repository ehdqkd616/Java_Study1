
public class ComparisonExample {

	public static void main(String[] args) {
		//== <= >= < > !=
		System.out.println(1!=2);
		String a = "hello";
		String b = new String("hello");
		String c = "hello";
		System.out.println(a==b);
		System.out.println(a==c);
		System.out.println(a.equals(b));
		
	}

}
