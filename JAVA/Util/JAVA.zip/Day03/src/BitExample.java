
public class BitExample {

	public static void main(String[] args) {
		byte a = 7; //0000_0111
		byte b = 11; //0000_1011
		System.out.println(a&b); //0000_0011
		System.out.println(a|b); //0000_1111
		System.out.println(a^b); //0000_1100
		
	}

}
